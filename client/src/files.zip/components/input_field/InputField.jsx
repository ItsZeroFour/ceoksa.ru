import React, { forwardRef } from "react";
import style from "./InputField.module.scss";
import { ReactComponent as Edit } from "../../assets/icons/account/edit.svg";

const InputField = forwardRef(
  (
    {
      icon: IconComponent,
      label,
      placeholder,
      id,
      type = "text",
      fieldProps,
      hasError,
      errorText,
      readOnly = false,
      children,
      onChange,
      fontSize,
      inputMode,
      value,
      name,
      prefix,
    },
    ref
  ) => {
    return (
      <div className={style.inputfield__wrapper}>
        {IconComponent && (
          <div className={style.inputfield__icon}>
            <IconComponent />
          </div>
        )}

        <div
          className={`${style.inputfield__content} ${
            hasError
              ? style.inputfield__content_error
              : style.inputfield__content
          }`}
        >
          {/* {label && <label htmlFor={id}>{label}</label>} */}
          <div className={style.inputwith__action}>
            {prefix && <span className={style.inputfield__prefix}>{prefix}</span>}
            <input
              id={id}
              type={type}
              placeholder={placeholder}
              onChange={onChange}
              readOnly={readOnly}
              {...fieldProps}
              inputMode={inputMode || "text"}
              ref={ref}
              name={name || ""}
              value={value && value}
              style={fontSize ? { fontSize: fontSize } : { fontSize: 16 }}
            />
            {children}

            {!readOnly && <Edit />}
          </div>
          {hasError && (
            <span className={style.input_error_text}>{errorText}</span>
          )}
        </div>
      </div>
    );
  }
);

export default InputField;
